// Define your project types here
export interface User {
  name: string;
}

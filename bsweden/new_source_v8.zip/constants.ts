// Define your project constants here
export const APP_NAME = "My New Website";
